package org.example.boardback.controller.user;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping
@RequiredArgsConstructor
/*
  사용자 프로필 단독 업로드/수정/삭제
 */
public class UserProfileImageController {
}
