package org.example.boardback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoardBackApplication {

    public static void main(String[] args) {
        SpringApplication.run(BoardBackApplication.class, args);
    }

}
